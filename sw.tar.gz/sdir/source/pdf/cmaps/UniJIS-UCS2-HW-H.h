/* This is an automatically generated file. Do not edit. */

/* UniJIS-UCS2-HW-H */

static const pdf_range cmap_UniJIS_UCS2_HW_H_ranges[] = {
{0x20,0x5b,0xe7},
{0x5c,0x5c,0x220f},
{0x5d,0x7e,0x124},
{0xa5,0xa5,0x123},
};

static pdf_cmap cmap_UniJIS_UCS2_HW_H = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "UniJIS-UCS2-HW-H",
	/* usecmap */ "UniJIS-UCS2-H", NULL,
	/* wmode */ 0,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	4, 4, (pdf_range*)cmap_UniJIS_UCS2_HW_H_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
